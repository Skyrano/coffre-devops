#
#   Hello World server in Python
#   Binds REP socket to tcp://*:5555
#   Expects b"Hello" from client, replies with b"World"
#

import time
import zmq

context = zmq.Context()
socket = context.socket(zmq.REP)
socket.bind("tcp://*:5555")

message = socket.recv_string()
print(message)

time.sleep(1)
if(message == "coucou"):
    socket.send_string("True")

else:
    socket.send_string("False")